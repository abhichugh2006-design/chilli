"""Command-line entry point: `python -m app.cli --help`."""
import argparse
import json
import os
import time
from pathlib import Path

DESCRIPTION = ("Public sector clerks classify documents faster. This tool uses LoRA to fine-tune GPT-2 "
               "to tag legal clauses in public records, improving efficiency and reducing manual review time.")


def _cmd_dataset(args) -> None:
    from app import core
    train, test = core.milestone_1(args.corpus, seed=args.seed)
    print(f"{len(train)} training clauses, {len(test)} test clauses")
    for label in core.LABELS:
        print(f"  {label:<26} train {sum(e.label == label for e in train):>3}   test {sum(e.label == label for e in test):>3}")
    print("\nExample training string:\n" + core.format_example(train[0]))


def _cmd_train(args) -> None:
    from app import core
    from app.storage import Store

    tokenizer, model = core.load_base(args.model)
    started = time.time()
    result = core.run_pipeline(tokenizer, model, args.corpus, r=args.rank, alpha=args.alpha,
                               targets=tuple(args.targets), epochs=args.epochs, lr=args.lr,
                               batch_size=args.batch_size, seed=args.seed)
    result["seconds"] = round(time.time() - started, 1)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(out)
    tokenizer.save_pretrained(out)
    (out / "tag_ids.json").write_text(json.dumps(result["tag_ids"], indent=2))
    (out / "metrics.json").write_text(json.dumps(result, indent=2))
    Store().put(f"run:{time.strftime('%Y%m%d-%H%M%S')}", {k: v for k, v in result.items() if k != "after_training"}
                | {"accuracy": result["after_training"]["accuracy"], "macro_f1": result["after_training"]["macro_f1"]})
    _print_metrics(result)
    print(f"\nMerged model saved to {out}/ ({result['seconds']}s)")


def _print_metrics(result: dict) -> None:
    after, before, eff = result["after_training"], result.get("before_training"), result.get("efficiency")
    if before:
        print(f"\nBefore training: accuracy {before['accuracy']:.1%}  macro-F1 {before['macro_f1']:.3f}")
    print(f"After training:  accuracy {after['accuracy']:.1%}  macro-F1 {after['macro_f1']:.3f}  (n={after['n']})")
    print("\nPer label:")
    for label, m in after["per_label"].items():
        print(f"  {label:<26} P {m['precision']:.2f}  R {m['recall']:.2f}  F1 {m['f1']:.2f}  n={m['support']}")
    if eff:
        print(f"\nEfficiency: trained {eff['trainable_params']:,} of {eff['total_params']:,} params "
              f"({eff['trainable_pct']:.3f}%), {eff['reduction_factor']}x fewer than full fine-tuning; "
              f"adapter {eff['adapter_mb_fp32']} MB vs {eff['full_finetune_mb_fp32']} MB full model")
    for m in after.get("mistakes", []):
        print(f"  miss: {m['true']} -> {m['pred']}: {m['text'][:80]}")


def _load_trained(path: str):
    from transformers import AutoTokenizer, GPT2LMHeadModel
    if not Path(path, "tag_ids.json").exists():
        raise SystemExit(f"No trained model in {path}/. Run `python -m app.cli train` first.")
    tokenizer = AutoTokenizer.from_pretrained(path)
    model = GPT2LMHeadModel.from_pretrained(path).eval()
    tag_ids = json.loads(Path(path, "tag_ids.json").read_text())
    return tokenizer, model, tag_ids


def _cmd_tag(args) -> None:
    from app import core
    tokenizer, model, tag_ids = _load_trained(args.model_dir)
    text = Path(args.file).read_text(encoding="utf-8") if args.file else args.text
    if not text:
        raise SystemExit("Give a file (--file) or some text (--text).")
    rows = core.tag_document(model, tokenizer, text, tag_ids)
    if args.json:
        print(json.dumps(rows, indent=2))
    else:
        print(core.render_tagged(rows))
    if args.out:
        Path(args.out).write_text(json.dumps(rows, indent=2) if args.out.endswith(".json") else core.render_tagged(rows))
        print(f"\nSaved to {args.out}")


def _cmd_evaluate(args) -> None:
    from app import core
    tokenizer, model, tag_ids = _load_trained(args.model_dir)
    _, test = core.milestone_1(args.corpus, seed=args.seed)
    report = core.evaluate(model, tokenizer, test, tag_ids)
    metrics_path = Path(args.model_dir, "metrics.json")
    saved = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
    _print_metrics({"after_training": report, "efficiency": saved.get("efficiency")})


def main(argv: list[str] | None = None) -> None:
    from app import core
    parser = argparse.ArgumentParser(prog="legal-document-lora-tagger", description=DESCRIPTION)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("hello", help="check that everything is wired up")

    p = sub.add_parser("dataset", help="milestone 1: show the clause dataset and the train/test split")
    p.add_argument("--corpus", default=str(core.DEFAULT_CORPUS))
    p.add_argument("--seed", type=int, default=0)

    p = sub.add_parser("train", help="milestones 2-6: add tags, inject LoRA, fine-tune, merge, evaluate, save")
    p.add_argument("--model", default=os.environ.get("BASE_MODEL", "gpt2"))
    p.add_argument("--corpus", default=str(core.DEFAULT_CORPUS))
    p.add_argument("--rank", type=int, default=8)
    p.add_argument("--alpha", type=float, default=16.0)
    p.add_argument("--targets", nargs="+", default=["c_attn"], help="GPT-2 layers to adapt: c_attn c_proj c_fc")
    p.add_argument("--epochs", type=int, default=8)
    p.add_argument("--lr", type=float, default=2e-3)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", default="models/lora-tagger")

    p = sub.add_parser("tag", help="milestone 5: tag every clause in a document")
    p.add_argument("--file")
    p.add_argument("--text")
    p.add_argument("--model-dir", default="models/lora-tagger")
    p.add_argument("--json", action="store_true")
    p.add_argument("--out")

    p = sub.add_parser("evaluate", help="milestone 6: score the saved model on the test split")
    p.add_argument("--model-dir", default="models/lora-tagger")
    p.add_argument("--corpus", default=str(core.DEFAULT_CORPUS))
    p.add_argument("--seed", type=int, default=0)

    args = parser.parse_args(argv)
    if args.command == "hello":
        print("Legal Document LoRA Tagger is ready. Open README.md for your milestones.")
    else:
        {"dataset": _cmd_dataset, "train": _cmd_train, "tag": _cmd_tag, "evaluate": _cmd_evaluate}[args.command](args)


if __name__ == "__main__":
    main()
