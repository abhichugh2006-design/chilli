# Legal Document LoRA Tagger

[![Built with askThili](https://ask.thili.ai/api/v1/public/projects/ax9x3mxmwc/badge.svg)](https://ask.thili.ai/b/ax9x3mxmwc)

This project develops a 'Legal Document LoRA Tagger' to assist public sector clerks. By applying LoRA to fine-tune GPT-2, the tool efficiently tags legal clauses in public records, significantly reducing manual review time and improving classification accuracy. This innovation streamlines document processing in public services.

## What you are building

**Goal.** You will build a tool that fine-tunes GPT-2 using LoRA to classify and tag legal clauses in public records, making document review faster for public sector clerks.

**Done when.** You will have successfully fine-tuned GPT-2 with a LoRA adapter to tag legal clauses, and the final output will be a tagged legal document with evaluated accuracy and efficiency.

## Milestones

Tick these off as you go, and commit after each one.

- [x] **1. Prepare a dataset of legal clauses for tagging**  
      Hint: Format your legal clause data for fine-tuning, similar to how the 'Fine-Tune GPT-2...' drill prepares text for classification.
- [x] **2. Extend GPT-2 tokenizer and model for custom tags**  
      Hint: Use the technique from 'Fine-Tune GPT-2...' to add special tokens for your tags and resize the model's embedding layer.
- [x] **3. Implement LoRA adapter and inject into GPT-2**  
      Hint: Apply the 'Build LoRA from Scratch' technique to create and inject LoRA layers into GPT-2's attention blocks.
- [x] **4. Fine-tune GPT-2 with LoRA on the clause dataset**  
      Hint: Combine the LoRA injection from 'Build LoRA from Scratch' with the fine-tuning process from 'Fine-Tune GPT-2...' on your clause dataset.
- [x] **5. Merge LoRA adapter and perform inference on new clauses**  
      Hint: Use the merging technique from 'Build LoRA from Scratch' and perform inference on new legal texts to generate tags.
- [x] **6. Evaluate tagging accuracy and model efficiency**  
      Hint: Calculate metrics like accuracy or F1-score on a test set, and consider the parameter count reduction from 'Build LoRA from Scratch' for efficiency.

## How it works

```
clause text ──► "Clause: …\nTag:" ──► GPT-2 (+ LoRA on attention) ──► next-token scores
                                                                     │
                                  only the 6 tag tokens are compared ┘──► <|tag:payment|> (94%)
```

| Milestone | Where | What it does |
|---|---|---|
| 1. Dataset | `corpus/legal_clauses.jsonl`, `load_clauses`, `train_test_split` | 72 hand-written public-sector clauses across 6 labels; stratified 75/25 split; prompt format `Clause: …\nTag:<tag><eos>` |
| 2. Tag tokens | `add_tag_tokens` | One special token per label (`<\|tag:termination\|>` …), embeddings resized, new rows initialised from hint words instead of noise |
| 3. LoRA | `LoRALinear`, `inject_lora` | `y = Wx + (α/r)·B(Ax)`, B starts at 0; handles GPT-2's `Conv1D` layout; base model frozen |
| 4. Fine-tune | `encode_batch`, `train` | Loss only on the tag + end tokens (prompt masked with -100); AdamW on LoRA params only |
| 5. Merge + infer | `merge_lora`, `predict`, `tag_document` | Folds `B@A·α/r` into W (zero inference overhead); constrained decoding over tag tokens; splits a document into clauses and tags each |
| 6. Evaluate | `classification_report`, `efficiency_report` | Accuracy, per-label P/R/F1, macro-F1, confusion matrix, misclassified clauses; trainable-param count and adapter size vs full fine-tuning |

Labels: `confidentiality`, `termination`, `indemnification`, `payment`, `governing_law`, `limitation_of_liability`.

## Usage

```bash
python -m app.cli dataset                                   # milestone 1: inspect the split
python -m app.cli train                                     # milestones 2-6: downloads gpt2 (~500 MB) once, trains, merges, evaluates
python -m app.cli tag --file examples/sample_contract.txt   # tag a document
python -m app.cli evaluate                                  # re-score the saved model
python -m app.cli train --rank 4 --targets c_attn c_proj    # stretch: try other ranks / layers
```

Training runs on a laptop CPU in a few minutes. The merged model, `tag_ids.json` and `metrics.json` are saved to
`models/lora-tagger/` (ignored by git). Each run's summary is also logged to `data/app.json`.

Tests use a tiny randomly-initialised GPT-2 built offline (`tests/conftest.py`), so CI never downloads weights.

## Run it

You need Python 3.12 and git.

```bash
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then choose a model; see the comments inside
python -m app.cli hello
pytest
```

Your work goes in `app/core.py` (one stub per milestone) and `tests/test_core.py`. The first tests pass already; they
check the plumbing.

## Settings and secrets

Model settings live in `.env`, which is ignored by git. **Never commit `.env` or paste a key into code.** If a key ever
reaches GitHub, treat it as leaked and make a new one.

## Stretch ideas

- Experiment with different LoRA ranks and target layers to observe their impact on tagging accuracy and model efficiency.
- Compare the performance and resource usage of your LoRA-tuned model against a fully fine-tuned GPT-2 model (if computational resources allow for comparison).
- Analyze specific types of legal clauses where the model performs exceptionally well or struggles, suggesting areas for future dataset improvement.
